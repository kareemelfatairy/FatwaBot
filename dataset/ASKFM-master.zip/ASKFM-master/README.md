## Arabic AskFM Dataset
### A Question/Answer dataset
This dataset is a merge of 98k questions and their respective answers as written by different authors on Askfm.

These Questions are Islamic questions.

It can be used as a knowledge base for information retrieval or as a base for a question answering system.
